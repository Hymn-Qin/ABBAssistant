local M = {}

local MONTHDAYS={
	["01"]=31,
	["02"]=28,
	["03"]=31,
	["04"]=30,
	["05"]=31,
	["06"]=30,
	["07"]=31,
	["08"]=31,
	["09"]=30,
	["10"]=31,
	["11"]=30,
	["12"]=31
};

local PRICEMAP={
	["十"]=10,
	["百"]=100,
	["千"]=1000,
	["万"]=10000,
};

local NUMMAP={
        ["零"]="0",
        ["一"]="1",
        ["幺"]="1",
        ["壹"]="1",
        ["二"]="2",
        ["三"]="3",
        ["四"]="4",
        ["五"]="5",
        ["六"]="6",
        ["七"]="7",
        ["八"]="8",
        ["九"]="9",
};

function easy_chnnum2num(chnnum)
        local i,strlen,hz,rst;
        if tonumber(chnnum) then
                return tostring(chnnum);
        end
        i=1;
        strlen=string.len(chnnum);
        rst="";
--      print_obj(NUMMAP);
        while i<strlen do
                hz=string.sub(chnnum,i,i+2);
--              print(hz);
                if NUMMAP[hz] then
                        rst=rst..NUMMAP[hz];
                end
                i=i+3;
        end
        return rst;
end

function getMonDayNum(month, isleap)
    local daYue = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
    if month == 2 then
        if isleap then
            return 29
        else
            return 28
        end
    elseif not daYue[month] then
        return 0
    else
        return daYue[month]
    end
end

function hex2BinStr(hex)
    local finalBinStr = ""
    local hex2BinMap = {}
    hex2BinMap["0"] = "0000"
    hex2BinMap["1"] = "0001"
    hex2BinMap["2"] = "0010"
    hex2BinMap["3"] = "0011"
    hex2BinMap["4"] = "0100"
    hex2BinMap["5"] = "0101"
    hex2BinMap["6"] = "0110"
    hex2BinMap["7"] = "0111"
    hex2BinMap["8"] = "1000"
    hex2BinMap["9"] = "1001"
    hex2BinMap["a"] = "1010"
    hex2BinMap["b"] = "1011"
    hex2BinMap["c"] = "1100"
    hex2BinMap["d"] = "1101"
    hex2BinMap["e"] = "1110"
    hex2BinMap["f"] = "1111"
    local binStr = string.format("%06x", hex)
    local len = string.len(binStr)
    for i=1,len do
        local c = string.sub(binStr, i, i)
        if not hex2BinMap[c] then
            print("Char not found in hex2BinMap!")
            os.exit()
        end
        finalBinStr = finalBinStr .. hex2BinMap[c]
    end
    return finalBinStr
end

-- 阳历日期转阴历日期
local function solar2lunar(year, month, day)
    local G = {"庚", "辛", "壬", "癸", "甲", "乙", "丙", "丁", "戊", "己"}
    local Z = {"申", "酉", "戌", "亥", "子", "丑", "寅", "卯", "辰", "巳", "午", "未"}
    local M = {
        {"丙寅", "丁卯", "戊辰", "己巳", "庚午", "辛未", "壬申", "癸酉", "甲戌", "乙亥", "丙子", "丁丑"},
        {"戊寅", "己卯", "庚辰", "辛巳", "壬午", "癸未", "甲申", "乙酉", "丙戌", "丁亥", "戊子", "己丑"},
        {"庚寅", "辛卯", "壬辰", "癸巳", "甲午", "乙未", "丙申", "丁酉", "戊戌", "己亥", "庚子", "辛丑"},
        {"壬寅", "癸卯", "甲辰", "乙巳", "丙午", "丁未", "戊申", "己酉", "庚戌", "辛亥", "壬子", "癸丑"},
        {"甲寅", "乙卯", "丙辰", "丁巳", "戊午", "己未", "庚申", "辛酉", "壬戌", "癸亥", "甲子", "乙丑"}
    }

    local ND = {
        "初一", "初二", "初三", "初四", "初五", "初六", "初七", "初八", "初九", "初十",
        "十一", "十二", "十三", "十四", "十五", "十六", "十七", "十八", "十九", "二十",
        "廿一", "廿二", "廿三", "廿四", "廿五", "廿六", "廿七", "廿八", "廿九", "三十"
    }
    local NM = {
        {"正月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "腊月"},
        {"闰一月", "闰二月", "闰三月", "闰四月", "闰五月", "闰六月", "闰七月", "闰八月", "闰九月", "闰十月", "闰十一月", "闰十二月"}
    }
    local DB = {
        0x04AE53,0x0A5748,0x5526BD,0x0D2650,0x0D9544,0x46AAB9,0x056A4D,0x09AD42,0x24AEB6,0x04AE4A,
        0x6A4DBE,0x0A4D52,0x0D2546,0x5D52BA,0x0B544E,0x0D6A43,0x296D37,0x095B4B,0x749BC1,0x049754,
        0x0A4B48,0x5B25BC,0x06A550,0x06D445,0x4ADAB8,0x02B64D,0x095742,0x2497B7,0x04974A,0x664B3E,
        0x0D4A51,0x0EA546,0x56D4BA,0x05AD4E,0x02B644,0x393738,0x092E4B,0x7C96BF,0x0C9553,0x0D4A48,
        0x6DA53B,0x0B554F,0x056A45,0x4AADB9,0x025D4D,0x092D42,0x2C95B6,0x0A954A,0x7B4ABD,0x06CA51,
        0x0B5546,0x555ABB,0x04DA4E,0x0A5B43,0x352BB8,0x052B4C,0x8A953F,0x0E9552,0x06AA48,0x6AD53C,
        0x0AB54F,0x04B645,0x4A5739,0x0A574D,0x052642,0x3E9335,0x0D9549,0x75AABE,0x056A51,0x096D46,
        0x54AEBB,0x04AD4F,0x0A4D43,0x4D26B7,0x0D254B,0x8D52BF,0x0B5452,0x0B6A47,0x696D3C,0x095B50,
        0x049B45,0x4A4BB9,0x0A4B4D,0xAB25C2,0x06A554,0x06D449,0x6ADA3D,0x0AB651,0x093746,0x5497BB,
        0x04974F,0x064B44,0x36A537,0x0EA54A,0x86B2BF,0x05AC53,0x0AB647,0x5936BC,0x092E50,0x0C9645,
        0x4D4AB8,0x0D4A4C,0x0DA541,0x25AAB6,0x056A49,0x7AADBD,0x025D52,0x092D47,0x5C95BA,0x0A954E,
        0x0B4A43,0x4B5537,0x0AD54A,0x955ABF,0x04BA53,0x0A5B48,0x652BBC,0x052B50,0x0A9345,0x474AB9,
        0x06AA4C,0x0AD541,0x24DAB6,0x04B64A,0x69573D,0x0A4E51,0x0D2646,0x5E933A,0x0D534D,0x05AA43,
        0x36B537,0x096D4B,0xB4AEBF,0x04AD53,0x0A4D48,0x6D25BC,0x0D254F,0x0D5244,0x5DAA38,0x0B5A4C,
        0x056D41,0x24ADB6,0x049B4A,0x7A4BBE,0x0A4B51,0x0AA546,0x5B52BA,0x06D24E,0x0ADA42,0x355B37,
        0x09374B,0x8497C1,0x049753,0x064B48,0x66A53C,0x0EA54F,0x06B244,0x4AB638,0x0AAE4C,0x092E42,
        0x3C9735,0x0C9649,0x7D4ABD,0x0D4A51,0x0DA545,0x55AABA,0x056A4E,0x0A6D43,0x452EB7,0x052D4B,
        0x8A95BF,0x0A9553,0x0B4A47,0x6B553B,0x0AD54F,0x055A45,0x4A5D38,0x0A5B4C,0x052B42,0x3A93B6,
        0x069349,0x7729BD,0x06AA51,0x0AD546,0x54DABA,0x04B64E,0x0A5743,0x452738,0x0D264A,0x8E933E,
        0x0D5252,0x0DAA47,0x66B53B,0x056D4F,0x04AE45,0x4A4EB9,0x0A4D4C,0x0D1541,0x2D92B5
    }
    
    local NL  = {year, 0, 0}
    local ISR = false
    local tmp = hex2BinStr(DB[year - 1900])
    local len = string.len(tmp)

    local data = {
    tonumber(string.sub(tmp, 20, len), 2),  -- 阳历春节天
    tonumber(string.sub(tmp, 18, 19), 2),   -- 阳历春节月
    tonumber(string.sub(tmp, 1, 4), 2), -- 闰月月份
    string.sub(tmp, 5, 17)          -- 大小月列表
    }

   if (data[2] > month) or ((data[1] > day) and (data[2] == month)) then
        tmp  = hex2BinStr(DB[year - 1901])
        data = {
        tonumber(string.sub(tmp, 20, len), 2),  -- 阳历春节天
        tonumber(string.sub(tmp, 18, 19), 2),   -- 阳历春节月
        tonumber(string.sub(tmp, 1, 4), 2), -- 闰月月份
        string.sub(tmp, 5, 17)          -- 大小月列表
        }
        NL[1] = year - 1
    end

    -- 判断是否为闰年
    if (0==NL[1]%4) and (0~=NL[1]%100) then
    ISR = true
    elseif (0==NL[1]%400) then
    ISR = true
    end

    if data[3]~=0 then
     table.insert(NM[1], data[3], NM[2][data[3]])
    end

    -- 计算天数差
    local days = 0
    if NL[1] < year then
    local i = 12
    while i > data[2] do
        days = days + getMonDayNum(i, ISR)
        i = i - 1
    end
    i = 0
    while month > i do
        days = days + getMonDayNum(i, ISR)
        i = i + 1
    end
    else
    local i = month
    while i > data[2] do
        i = i - 1
        if i == data[2] then
        break
        end
        days = days + getMonDayNum(i, ISR)
    end
    end

    if data[2] == month and NL[1] == year then
    days = days +  day - data[1]
    end
    if data[2] ~= month or NL[1] ~= year then
    days = days + day
    days = days + (getMonDayNum(data[2], ISR) - data[1])
    end
    i = 0
    local tmp1 = nil
    while i < days do
    tmp1 = string.sub(data[4], NL[2]+1, NL[2]+1)
    NL[3] = NL[3] + 1
    if ((NL[2]-1) == data[3]) and data[3] then
        if 0~=tonumber(tmp1) and (NL[3] == 30) then
        NL[2] = NL[2] + 1
        NL[3] = 0
        elseif 0==tonumber(tmp1) and (NL[3] == 29) then
        NL[2] = NL[2] + 1
        NL[3] = 0
        end
    elseif 0~=tonumber(tmp1) and (NL[3] == 30) then
        NL[2] = NL[2] + 1
        NL[3] = 0
    elseif 0==tonumber(tmp1) and (NL[3] == 29) then
        NL[2] = NL[2] + 1
        NL[3] = 0
    end
    i = i + 1
    end
    return NL[1], NM[1][NL[2]+1], ND[NL[3]+1]
end

-- 把农历日期转成纯数字,如: 2014闰九月初一, 返回: 2014, 9, 1
local function lunar2num(year, nlMonth, nlDay)
    local map = {}
    local month, day = nil, nil
    map["一"] = 1
    map["正"] = 1
    map["二"] = 2
    map["三"] = 3
    map["四"] = 4
    map["五"] = 5
    map["六"] = 6
    map["七"] = 7
    map["八"] = 8
    map["九"] = 9
    map["十"] = 10
    map["十一"] = 11
    map["十二"] = 12
    map["腊"] = 12
    if string.sub(nlMonth, 1, 3) == "闰" then
    nlMonth = string.sub(nlMonth, 4, string.len(nlMonth))
    end
    nlMonth = string.sub(nlMonth, 1, string.len(nlMonth)-3)
    if map[nlMonth] then
    month = map[nlMonth]
    else
    print("Cannot translate lunar to number!")
    os.exit()
    end
    local tmp = string.sub(nlDay, 1, 3)
    local ge, shi = 0, 0
    if tmp == "初" then
    shi = 0
    elseif tmp == "十" or tmp=="二" then
    shi = 1
    elseif tmp == "廿" or tmp=="三" then
    shi = 2
    end
    ge = map[string.sub(nlDay, 4, string.len(nlDay))]
    day = shi * 10 + ge
    return year, month, day
end

function is_leap_year(y)
	local year,rst;
	year=tonumber(y);
	rst=false;
	if year%4==0 and year%100~=0 then
		rst=true;
	elseif year%400==0 then
		rst=true;
	end
	return rst;
end

function number_align(n)
	local num;
	--print("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
	--print(n);
  ---[[临时方案
  if type(n)=="string" and string.len(n) == 0 then
      return n;
  end
  --]]
	num=tonumber(n);
	if not num then
		num=wtk_chn2number(n);
		---[[临时方案
		if not num then 
		    num = 0
		end
		--]]
	end
--	print(num);
	if not num then
		num=easy_chnnum2num(n);
	end
	num=tonumber(num);
--	print(num);
	if num>=0 and num<10 then
		return "0"..tostring(num);
	end
	return tostring(num);
end

function M:pub_actpls_year(attr)
	local var,var2,key,key2,year,month,day,rst1,r,num,tmp;

    -- 处理年份 --------
	key="year";
	var=get_data_from_attr(key,attr);  --wtk_actpls_dict_get(d,key);
	if var==nil then
		year=os.date("%Y");
		year=tostring(year);
	else
		if not tonumber(var) then
			year=easy_chnnum2num(var);
		else
			year=var;
		end
	end

    --  处理月日 ---
	key="month";
	--var=wtk_actpls_dict_get(d,key);
        var=get_data_from_attr(key,attr);
	key2="day";
	--var2=wtk_actpls_dict_get(d,key2);
        var2=get_data_from_attr(key2,attr);
    
    --如果月日都不存在，直接返回年 --
	if not var and not var2 then
		return 0,tonumber(year);
	end
    --如果只有月，没有日，返回年日
	if var and not var2 then
		tmp=wtk_chn2number(var);
		if tmp then
			tmp=number_align(tmp);
		else
			tmp=number_align(var);
		end
		rst1=tostring(year)..tmp;
		return 0, rst1;
	end
	if var and var2 then
		tmp=wtk_chn2number(var);
        month=var
		if tmp then
			month=tmp;
		end
		tmp=wtk_chn2number(var2);
        day=var2
		if tmp then
			day=tmp;
		end
		month=number_align(month);
		day=number_align(day);

        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
            if tonumber(month) > 12 then
                return 0,month..day;
            else
		return 0,tostring(year)..month..day;
            end
        end

	end
	if not var then
		month=os.date("%m");
		month=tostring(month);
	else
		month=tostring(wtk_chn2number(var));
	end
	month=number_align(month);
	if var2 and not var then
        tmp = wtk_chn2number(var2);
        day=var2
        if tmp then
            day = tmp;
        end
        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
		    rst1=year..month..number_align(tostring(day));
		    return 0, tonumber(rst1);
        end
	end
	if not var2 then
		day=os.date("%d");
		day=tostring(day);
	else
		day=tostring(wtk_chn2number(var2));
	end
	day=number_align(day);
	rst1=year..month..day;
--	print_obj(rst1);
	return 0,tonumber(rst1);
end


--判断某月是否有31天
local function has_31day(i)
    if i==1 or i==3 or i==5 or i==7 or i==8 or i==10 or i==12 then
        return 1
    else
        return 0
    end
end

-- 判断是否为闰年
local function isLeapYear(year)
    if 0==year%4 and year%100 ~=0 then
	    return 1
    end
    if 0==year%400 then
	    return 1
    end
    return 0
end

--function pub_actpls_yearnearby(d,pls)  --缺少年和月时，默认日期的根据前日期来判断,考虑的是就近原则
function M:pub_actpls_yearnearby(d)  --缺少年和月时，默认日期的根据前日期来判断,考虑的是就近原则
	local var,var2,key,key2,year,month,day,rst1,r,num,tmp;
    -- 处理年份 --------
	key="year";
	--var=wtk_actpls_dict_get(d,key);
    var = get_data_from_attr(key,d)
	if not var then
		year=os.date("%Y");
        ---默认年份的处理：
        ---1 2 | 3 4 5 6 7 8 9 10 | 11 12 {三段式}
        ---a.当前月份“1~2月”，用户说“11月或12月”，默认年份为【去年】；其他，默认年份为【今年】。
        ---b.当前月份“3~10月”，用户说“×月”，默认年份为【今年】。
        ---c.当前月份“11~12月”，用户说“1月或2月”，默认年份为【明年】；其他，默认年份为【今年】。
        nowmonth=os.date("%m")
        --print(nowmonth,type(nowmonth),'=====month')
        --print(year,'=====year')
        --varmonth=wtk_actpls_dict_get(d,"month");
        varmonth=get_data_from_attr("month",d)
       -- print(varmonth,type(varmonth),'=====varmonth')
        if varmonth then
            if (nowmonth=='01' or nowmonth =='02') and (varmonth=='11' or varmonth=='12') then
                year=tonumber(year)-1
            elseif (nowmonth=='11' or nowmonth =='12') and (varmonth=='1' or varmonth=='2') then
                year=tonumber(year)+1
            end
        end
        ----------
		year=tostring(year);
	else
		if not tonumber(var) then
			year=easy_chnnum2num(var);
		else
			year=var;
		end
	end

    --  处理月日 ---
	key="month";
	--var=wtk_actpls_dict_get(d,key);
    var=get_data_from_attr(key,d);
	key2="day";
	--var2=wtk_actpls_dict_get(d,key2);
    var2=get_data_from_attr(key2,d);
  
    --如果月日都不存在，直接返回年 --
	if not var and not var2 then
		return 0,tonumber(year);
	end
    --如果只有月，没有日，返回年月
	if var and not var2 then
		tmp=wtk_chn2number(var);
		if tmp then
			tmp=number_align(tmp);
		else
			tmp=number_align(var);
		end
		rst1=tostring(year)..tmp;
		return 0, rst1;
	end
	if var and var2 then
		tmp=wtk_chn2number(var);
        month=var
		if tmp then
			month=tmp;
		end
		tmp=wtk_chn2number(var2);
        day=var2
		if tmp then
			day=tmp;
		end
		month=number_align(month);
		day=number_align(day);

        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
            if tonumber(month) > 12 then
                return 0,month..day;
            else
		        return 0,tostring(year)..month..day;
            end
        end

	end
    ----默认月份的处理：
    ----1 … 5 | 6 … 25 | 26 … 31
    ----a.当前日期“1~5号”，用户说“26~31号”，默认月份为【上个月】；其他，默认月份为【本月】。
    ----b.当前日期“6~25号”，用户说“×号”，默认月份为【本月】。
    ----c.当前日期“26~31号”，用户说“1~5号”，默认月份为【下个月】；其他，默认月份为【本月】。
	if not var then
		month=os.date("%m");
		month=tonumber(month);
        nowmonth=month
		nowday=os.date("%d");
        if var2 then
            tmp = wtk_chn2number(var2);
            day=var2
            if tmp then
                day = tmp;
            end
            --print(day,type(day),tmp,type(tmp),'====day')
            --print(nowday,nowmonth,month,'====nowday')
            if (tonumber(nowday)>=1 and tonumber(nowday)<=5) and (tonumber(day)>=26 and tonumber(day)<=31) then
                if tonumber(day)==29 and nowmonth-1==2 then
                    if isLeapYear(tonumber(year))==1 then
                        month=nowmonth-1
                    end
                elseif tonumber(day)==30 and nowmonth-1==2 then
                    month=nowmonth
                    --print(month,nowmonth,'nnnnnnnnnnnnnn')
                elseif tonumber(day)==31 then
                    if nowmonth-1==0 then
                        newmonth=12
                    else
                        newmonth=nowmonth-1
                    end
                    --print(newmongth,'=============')
                    if has_31day(newmonth)==1 then
                        month=nowmonth-1
                    end
                else
                    month=nowmonth-1
                end
                
            elseif (tonumber(nowday)>=26 and tonumber(nowday)<=31) and (tonumber(day)>=1 and tonumber(day)<=5) then
                month=nowmonth+1
            end
            if nowmonth==1 and month==0 then
                month=12
                year=tonumber(year)-1
            elseif nowmonth==12 and month==13 then
                month=1
                year=tonumber(year)+1
            end
        end
	else
		month=tostring(wtk_chn2number(var));
	end
    ----------------
	month=number_align(month);
	if var2 and not var then
	      tmp = wtk_chn2number(var2);
        day=var2
        if tmp then
            day = tmp;
        end
        
        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
		    rst1=year..month..number_align(tostring(day));
		    return 0, tonumber(rst1);
        end
	end
	if not var2 then
		day=os.date("%d");
		day=tostring(day);
	else
		day=tostring(wtk_chn2number(var2));
	end
	day=number_align(day);
	rst1=year..month..day;
--	print_obj(rst1);
	return 0,tonumber(rst1);
end


--function pub_actpls_yearfuture(d,pls)  --缺少年和月时，默认日期的根据前日期来判断,全部默认成未来日期
function M:pub_actpls_yearfuture(d)  --缺少年和月时，默认日期的根据前日期来判断,全部默认成未来日期
    local var,var2,key,key2,year,month,day,rst1,r,num,tmp;

    -- 处理年份 --------
    key="year";
    --var=wtk_actpls_dict_get(d,key);
    var=get_data_from_attr(key,d);
    if not var then
		    year=os.date("%Y");
        ---默认年份的处理：
        ---a.当前月份比处理的月份大，则年份默认成明年。

        nowmonth=os.date("%m")
		    nowday=os.date("%d");
        --print(nowmonth,type(nowmonth),'=====month')
        --print(year,'=====year')
        --varmonth=wtk_actpls_dict_get(d,"month");
        varmonth=get_data_from_attr("month",d);
        --varday=wtk_actpls_dict_get(d,"day");
        varday=get_data_from_attr("day",d);
       -- print(varmonth,type(varmonth),'=====varmonth')
        if varmonth and not varday then
            if tonumber(nowmonth)>tonumber(varmonth) then
                year=tonumber(year)+1
            end
        elseif varmonth and varday then
            if tonumber(nowmonth)>tonumber(varmonth) then
                year=tonumber(year)+1
            elseif tonumber(nowmonth)==tonumber(varmonth) and tonumber(nowday)>tonumber(varday) then
                year=tonumber(year)+1
            end            
        end
        ----------
		year=tostring(year);
	else
		if not tonumber(var) then
			year=easy_chnnum2num(var);
		else
			year=var;
		end
	end

    --  处理月日 ---
	key="month";
	--var=wtk_actpls_dict_get(d,key);
	var=get_data_from_attr(key,d);
	key2="day";
	--var2=wtk_actpls_dict_get(d,key2);
	var2=get_data_from_attr(key2,d);
    
    --如果月日都不存在，直接返回年 --
	if not var and not var2 then
		return 0,tonumber(year);
	end
    --如果只有月，没有日，返回年月
	if var and not var2 then
		tmp=wtk_chn2number(var);
		if tmp then
			tmp=number_align(tmp);
		else
			tmp=number_align(var);
		end
		rst1=tostring(year)..tmp;
		return 0, rst1;
	end
    --如果有月有日，直接返回年月日
	if var and var2 then
		tmp=wtk_chn2number(var);
        month=var
		if tmp then
			month=tmp;
		end
		tmp=wtk_chn2number(var2);
        day=var2
		if tmp then
			day=tmp;
		end
		month=number_align(month);
		day=number_align(day);

        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
            if tonumber(month) > 12 then
                return 0,month..day;
            else
		        return 0,tostring(year)..month..day;
            end
        end

	end
    ----默认月份的处理：（只有日没有月）
    ----当前日期大于处理的日期，默认月份为下个月
  
	if not var then
		month=os.date("%m");
		month=tonumber(month);
        nowmonth=month
		nowday=os.date("%d");
        if var2 then
            tmp = wtk_chn2number(var2);
            day=var2
            if tmp then
                day = tmp;
            end
            --print(day,type(day),tmp,type(tmp),'====day')
            --print(nowday,nowmonth,month,'====nowday')
            if tonumber(nowday)>tonumber(day) then
                month=nowmonth+1
            else
                month=nowmonth
            end

            if nowmonth==12 and month==13 then
                month=1
                year=tonumber(year)+1
            end
        end
	else
		month=tostring(wtk_chn2number(var));
	end
    ----------------
	month=number_align(month);
	if var2 and not var then
        tmp = wtk_chn2number(var2);
        day=var2
        if tmp then
            day = tmp;
        end
        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
		    rst1=year..month..number_align(tostring(day));
		    return 0, tonumber(rst1);
        end
	end
	if not var2 then
		day=os.date("%d");
		day=tostring(day);
	else
		day=tostring(wtk_chn2number(var2));
	end
	day=number_align(day);
	rst1=year..month..day;
--	print_obj(rst1);
	return 0,tonumber(rst1);
end


--function pub_actpls_yearfutureaddnearby(d,pls)  --缺少年和月时，默认日期的根据前日期来判断,全部默认成未来日期+微调（默认年份为“-1个月”；默认月份为“-3天”；默认星期皆不参与微调）
function M:pub_actpls_yearfutureaddnearby(d)  --缺少年和月时，默认日期的根据前日期来判断,全部默认成未来日期+微调（默认年份为“-1个月”；默认月份为“-3天”；默认星期皆不参与微调）
	local var,var2,key,key2,year,month,day,rst1,r,num,tmp;

    -- 处理年份 --------
	key="year";
	--var=wtk_actpls_dict_get(d,key);
	var=get_data_from_attr(key,d);
	if not var then
		year=os.date("%Y");
        ---默认年份的处理：
        ---当前月份-处理的月份>1,年份默认成明年，否则,年份默认成今年。

        nowmonth=os.date("%m")
        --print(nowmonth,type(nowmonth),'=====month')
        --print(year,'=====year')
        --varmonth=wtk_actpls_dict_get(d,"month");
        varmonth=get_data_from_attr("month",d);
       -- print(varmonth,type(varmonth),'=====varmonth')
        if varmonth and not tonumber(varmonth) then
            varmonth=easy_chnnum2num(varmonth)
        end 
        if varmonth then
            if tonumber(nowmonth)-tonumber(varmonth)>1 then
                year=tonumber(year)+1
            end
        end
        ----------
		year=tostring(year);
	else
		if not tonumber(var) then
			year=easy_chnnum2num(var);
		else
			year=var;
		end
	end
  
    --  处理月日 ---
	key="month";
	--var=wtk_actpls_dict_get(d,key);
	var=get_data_from_attr(key,d);
	key2="day";
	--var2=wtk_actpls_dict_get(d,key2);
	var2=get_data_from_attr(key2,d);    
    --如果月日都不存在，直接返回年 --
	if not var and not var2 then
		return 0,tonumber(year);
	end
    --如果只有月，没有日，返回年月
	if var and not var2 then
		tmp=wtk_chn2number(var);
		if tmp then
			tmp=number_align(tmp);
		else
			tmp=number_align(var);
		end
		rst1=tostring(year)..tmp;
		return 0, rst1;
	end
    --如果有月有日，直接返回年月日
	if var and var2 then
		tmp=wtk_chn2number(var);
		    month=var
		if tmp then
			month=tmp;
		end
		tmp=wtk_chn2number(var2);
		   day=var2
		if tmp then
			day=tmp;
		end
	
		month=number_align(month);
		day=number_align(day);    
        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
            if tonumber(month) > 12 then
                return 0,month..day;
            else
		        return 0,tostring(year)..month..day;
            end
        end

	end
    ----默认月份的处理：（只有日没有月）
    ----当前日期-处理的日期>3，默认月份为下个月,否则默认为当月
  
	if not var then
		month=os.date("%m");
		month=tonumber(month);
        nowmonth=month
		nowday=os.date("%d");
        if var2 then
            tmp = wtk_chn2number(var2);
            day=var2
            if tmp then
               day = tmp;
            end
            --print(day,type(day),tmp,type(tmp),'====day')
            --print(nowday,nowmonth,month,'====nowday')
            if tonumber(nowday)-tonumber(day)>3 then
                month=nowmonth+1
            else
                month=nowmonth
            end

            if nowmonth==12 and month==13 then
                month=1
                year=tonumber(year)+1
            end
        end
	else
		month=tostring(wtk_chn2number(var));		
	end
    ----------------
	month=number_align(month);
	if var2 and not var then
        tmp = wtk_chn2number(var2);
        day=var2
        if tmp then
            day = tmp;
        end
        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
		    rst1=year..month..number_align(tostring(day));
		    return 0, tonumber(rst1);
        end
	end
	if not var2 then
		day=os.date("%d");
		day=tostring(day);
	else
		day=tostring(wtk_chn2number(var2));		
	end
	day=number_align(day);
	rst1=year..month..day;
--	print_obj(rst1);
	return 0,tonumber(rst1);
end


--function pub_actpls_yearpastaddnearby(d,pls)  --缺少年和月时，默认日期的根据前日期来判断,全部默认成过去日期+微调（默认年份为“+1个月”；默认月份为“+3天”；默认星期皆不参与微调）
function M:pub_actpls_yearpastaddnearby(d)  --缺少年和月时，默认日期的根据前日期来判断,全部默认成过去日期+微调（默认年份为“+1个月”；默认月份为“+3天”；默认星期皆不参与微调）
	local var,var2,key,key2,year,month,day,rst1,r,num,tmp;

    -- 处理年份 --------
	key="year";
	--var=wtk_actpls_dict_get(d,key);
	var=get_data_from_attr(key,d);
	if not var then
		year=os.date("%Y");
        ---默认年份的处理：
        ---处理的月份-当前月份>1,年份默认成去年，否则,年份默认成今年。

        nowmonth=os.date("%m")
        --print(nowmonth,type(nowmonth),'=====month')
        --print(year,'=====year')
        --varmonth=wtk_actpls_dict_get(d,"month");
        varmonth=get_data_from_attr("month",d);
       -- print(varmonth,type(varmonth),'=====varmonth')
        if varmonth and not tonumber(varmonth) then
            varmonth=easy_chnnum2num(varmonth)
        end  
        if varmonth then
            if tonumber(varmonth)-tonumber(nowmonth)>1 then
                year=tonumber(year)-1
            end
        end
        ----------
		year=tostring(year);
	else
		if not tonumber(var) then
			year=easy_chnnum2num(var);
		else
			year=var;
		end
	end

    --  处理月日 ---
	key="month";
	--var=wtk_actpls_dict_get(d,key);
	var=get_data_from_attr(key,d);
	key2="day";
	--var2=wtk_actpls_dict_get(d,key2);
	var2=get_data_from_attr(key2,d);
    
    --如果月日都不存在，直接返回年 --
	if not var and not var2 then
		return 0,tonumber(year);
	end
    --如果只有月，没有日，返回年月
	if var and not var2 then
		tmp=wtk_chn2number(var);
		if tmp then
			tmp=number_align(tmp);
		else
			tmp=number_align(var);
		end
		rst1=tostring(year)..tmp;
		return 0, rst1;
	end
    --如果有月有日，直接返回年月日
	if var and var2 then
		tmp=wtk_chn2number(var);
        month=var
		if tmp then
			month=tmp;
		end
		tmp=wtk_chn2number(var2);
        day=var2
		if tmp then
			day=tmp;
		end
		month=number_align(month);
		day=number_align(day);

        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
            if tonumber(month) > 12 then
                return 0,month..day;
            else
		        return 0,tostring(year)..month..day;
            end
        end

	end
    ----默认月份的处理：（只有日没有月）
    ----处理的日期-当前日期>3，默认月份为上个月,否则默认为当月
  
	if not var then
		month=os.date("%m");
		month=tonumber(month);
        nowmonth=month
		nowday=os.date("%d");
        if var2 then
            tmp = wtk_chn2number(var2);
            day=var2
            if tmp then
                day = tmp;
            end
            --print(day,type(day),tmp,type(tmp),'====day')
            --print(nowday,nowmonth,month,'====nowday')
            if tonumber(day)-tonumber(nowday)>3 then
                month=nowmonth-1
            else
                month=nowmonth
            end

            if nowmonth==1 and month==0 then
                month=12
                year=tonumber(year)-1
            end
        end
	else
		month=tostring(wtk_chn2number(var));
	end
    ----------------
	month=number_align(month);
	if var2 and not var then
        tmp = wtk_chn2number(var2);
        day=var2
        if tmp then
            day = tmp;
        end
        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
		    rst1=year..month..number_align(tostring(day));
		    return 0, tonumber(rst1);
        end
	end
	if not var2 then
		day=os.date("%d");
		day=tostring(day);
	else
		day=tostring(wtk_chn2number(var2));
	end
	day=number_align(day);
	rst1=year..month..day;
--	print_obj(rst1);
	return 0,tonumber(rst1);
end


--日历间隔处理 三天之后、三年之后
function M:pub_actpls_year3(attr)
	local var,var2,key,key2,year,month,day,rst1,r,num,tmp;

    -- 处理年份 --------
	key="year";
	var=get_data_from_attr(key,attr); --wtk_actpls_dict_get(d,key);
	if not var then
		year=0;
	else
		tmp=wtk_chn2number(var);
		if tmp then
			year=tmp;
		else
			year=var;
		end
	end

    --  处理月 ---
	key="month";
	var=get_data_from_attr(key,attr); --wtk_actpls_dict_get(d,key);

	if not var then
		month=0;
	else
		tmp=wtk_chn2number(var);
		if tmp then
			month=tmp;
		else
			month=var;
		end
	end
    --  处理日 ---
	key="day";
	var=get_data_from_attr(key,attr); --wtk_actpls_dict_get(d,key);

	if not var then
		day=0;
	else
		tmp=wtk_chn2number(var);
		if tmp then
			day=tmp;
		else
			day=var;
		end
	end
    year=number_align(year);
    month=number_align(month);
    day=number_align(day);
   -- print(year,month,day,"==============")
	rst1=tostring(year)..":"..tostring(month)..":"..tostring(day);
--	print_obj(rst1);
	return 0,rst1;
end

--处理阴历日期
function M:pub_actpls_lyear(attr)
    local var,var2,key,key2,year,month,day,rst1,r,num,tmp;
    local cury,curm,curd,ly,lm,ld;
    cury = tonumber(os.date("%Y"));
    curm = tonumber(os.date("%m"));
    curd = tonumber(os.date("%d"));    
    tempyear,tempmonth,tempday = solar2lunar(cury,curm,curd);
    ly,lm,ld = lunar2num(tempyear,tempmonth,tempday);

    -- 处理年份 --------
    key="year";
    var=get_data_from_attr(key,attr); --wtk_actpls_dict_get(d,key);
    if not var then
        year=tostring(ly);
    else
        if not tonumber(var) then
            year=easy_chnnum2num(var);
        else
            year=var;
        end
    end

    --  处理月日 ---
    key="month";
    var=get_data_from_attr(key,attr); --wtk_actpls_dict_get(d,key);
    key2="day";
    var2=get_data_from_attr(key2,attr);--wtk_actpls_dict_get(d,key2);
    --如果月日都不存在，直接返回年 --
    if not var and not var2 then
        return 0,tonumber(year);
    end

    --如果只有月，没有日，返回年日
    if var and not var2 then
        tmp=wtk_chn2number(var);
        if tmp then
            tmp=number_align(tmp);
        else
            tmp=number_align(var);
        end
        rst1=tostring(year)..tmp;
        return 0, rst1;
    end
    if var and var2 then
        tmp=wtk_chn2number(var);
        month=var
        if tmp then
            month=tmp;
        end
        tmp=wtk_chn2number(var2);
        day=var2
        if tmp then
            day=tmp;
        end
        month=number_align(month);
        day=number_align(day);

        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
            if tonumber(month) > 12 then
                return 0,month..day;
            else
                return 0,tostring(year)..month..day;
            end
        end

    end
    if not var then
        month=tostring(lm);
    else
        month=tostring(wtk_chn2number(var));
    end
    month=number_align(month);
    if var2 and not var then
        tmp = wtk_chn2number(var2);
        day=var2
        if tmp then
            day = tmp;
        end
        if tonumber(day) > 1231 then
            return 0,day;
        elseif tonumber(day) > 100 then
            return 0,tostring(year)..day;
        else
            rst1=year..month..number_align(tostring(day));
            return 0, tonumber(rst1);
        end
    end
    if not var2 then
        day=tostring(ld);
    else
        day=tostring(wtk_chn2number(var2));
    end
    day=number_align(day);
    rst1=year..month..day;

    return 0,tonumber(rst1);
end





function M:pub_actpls_xyear(attr)
	local key,var,refyear;
	key="offset";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		refyear=os.date("%Y");
		var=tonumber(var);
		return 0,tostring(refyear+var);
	end
end

function M:pub_actpls_lxyear(d) -- 查询农历日期时相对年的默认使用农历年份，如：明年正月初三
	local key,var,refyear;
	key="offset";
	var=get_data_from_attr(key,d);--var=wtk_actpls_dict_get(d,key);
	
    cury = tonumber(os.date("%Y"));
    curm = tonumber(os.date("%m"));
    curd = tonumber(os.date("%d"));
    tempyear,tempmonth,tempday = solar2lunar(cury,curm,curd);
    ly,lm,ld = lunar2num(tempyear,tempmonth,tempday);
	if var then
		--refyear=os.date("%Y");
		var=tonumber(var);
		return 0,tostring(ly+var);
	end
end

function M:pub_actpls_wday(d)
	local key,var,cur,offset,wday,offset2,month,day,year,mdays;
	cur=os.date("%w");
--	print_obj(cur);
	key="offset";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		offset=tonumber(var);
	end
	key="wday";
	var=get_data_from_attr(key,attr); --wtk_actpls_dict_get(d,key);
	if var then
		wday=easy_chnnum2num(var);
		wday=tonumber(wday);
	end
--	cur2=os.date("%Y%m%d");
--	cur2=tonumber(cur2);
	if offset and wday then
		offset2=offset-(cur-wday);
--		print(offset2);
	end
	if not offset and wday then
		offset2=wday-cur;
	end
    
    if offset2 then
        dsttime = os.time() + tonumber(offset2)*24*3600;
        return 0,os.date("%Y%m%d",dsttime);
    end

	return 0,os.date("%Y%m%d");
end


--根据是否过去决定是选择本周还是下周
function M:pub_actpls_wday2(attr)
	local key,var,cur,offset,wday,offset2,month,day,year,mdays;
	cur=os.date("%w");
    if cur=='0' then --周日默认成一周的第七天
        cur=7
    end
--	print_obj(cur);
	key="offset";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		offset=tonumber(var);
	end
	key="wday";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		wday=easy_chnnum2num(var);
		wday=tonumber(wday);
	end
--	cur2=os.date("%Y%m%d");
--	cur2=tonumber(cur2);
	if offset and wday then
		offset2=offset-(cur-wday);
--		print(offset2);
	end
	if not offset and wday then
		offset2=wday-cur;
      if offset2 < 0 then
            offset2 = offset2 + 7;
      end
	end
    
    if offset2 then
        dsttime = os.time() + tonumber(offset2)*24*3600;
        return 0,os.date("%Y%m%d",dsttime);
    end

	return 0,os.date("%Y%m%d");
end


--根据当前是周几来判断是这周还是下周，考虑的是就近原则
function M:pub_actpls_wday2nearby(d)
	local key,var,cur,offset,wday,offset2,month,day,year,mdays;
	cur=os.date("%w");
    if cur=='0' then --周日默认成一周的第七天
        cur=7
    end
--	print_obj(cur);
	key="offset";
	var=get_data_from_attr(key,d);--var=wtk_actpls_dict_get(d,key);
	if var then
		offset=tonumber(var);
	end
	key="wday";
	var=get_data_from_attr(key,d)--wtk_actpls_dict_get(d,key);
	
	if var then
		wday=easy_chnnum2num(var);
		wday=tonumber(wday);
	end
--	cur2=os.date("%Y%m%d");
--	cur2=tonumber(cur2);
	if offset and wday then
		offset2=offset-(cur-wday);
--		print(offset2);
	end

    ----默认星期的处理：
    ----一 二 | 三 四 五 | 六 日  
    ----a.当前为“周一或周二”，用户说“周六或周日”，默认指【上周】；其他，默认指【本周】。
    ----b.当前为“周三~周五”，用户说“周×”，默认指【本周】。
    ----c.当前为“周六或周日”，用户说“周一或周二”，默认指【下周】；其他，默认指【本周】。

	if not offset and wday then
	--	offset2=wday-cur;
    --  if offset2 < 0 then
     --       offset2 = offset2 + 7;
     -- end
        --print(cur,wday,type(cur),type(wday),'====cur')
        if (tonumber(cur)==1 or tonumber(cur)==2) and (wday==6 or wday==7) then
            offset2=wday-tonumber(cur)-7
        elseif (tonumber(cur)==6 or tonumber(cur)==7) and (wday==1 or wday==2) then
            offset2=wday-tonumber(cur)+7
        else
            offset2=wday-tonumber(cur)
        end
	end
    
    if offset2 then
        dsttime = os.time() + tonumber(offset2)*24*3600;
        return 0,os.date("%Y%m%d",dsttime);
    end

	return 0,os.date("%Y%m%d");
end


--根据当前是周几来判断是这周还是下周，考虑的是过去原则
function M:pub_actpls_wday2past(d)
	local key,var,cur,offset,wday,offset2,month,day,year,mdays;
	cur=os.date("%w");
    if cur=='0' then --周日默认成一周的第七天
        cur=7
    end
--	print_obj(cur);
	key="offset";
	var=get_data_from_attr(key,d);--var=wtk_actpls_dict_get(d,key);
	if var then
        var=easy_chnnum2num(var);
		offset=tonumber(var);
	end
	key="wday";
	var=get_data_from_attr(key,d);--var=wtk_actpls_dict_get(d,key);
	if var then
		wday=easy_chnnum2num(var);
		wday=tonumber(wday);
	end
--	cur2=os.date("%Y%m%d");
--	cur2=tonumber(cur2);
	if offset and wday then
		offset2=offset-(cur-wday);
--		print(offset2);
	end

	if not offset and wday then
		offset2=wday-cur;
        if offset2 ~= 0 then
            offset2 = offset2 - 7;
        end
	end
    
    if offset2 then
        dsttime = os.time() + tonumber(offset2)*24*3600;
        return 0,os.date("%Y%m%d",dsttime);
    end

	return 0,os.date("%Y%m%d");
end

function M:pub_actpls_num(attr)
	local key,var,rst,var2,tmp;
	key="value";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		rst=wtk_chn2number(var);
        --print(rst)
		if rst then
			return 0, tostring(rst);
		else
			var2=chn2number_process_wan2(var);
			--print_obj(var2);
			if var2 then
				return 0, tostring(var2);
			end
			var2=abnormal_chn2number(var);
			if var2 then
				return 0,var2;
			end
			var2=easy_chnnum2num(var);
			if var2 then
				return 0,var2;
			end
		end
		return 0,0
	end
	key="left";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	tmp=wtk_chn2number(var);
	if tmp then
		var=tostring(tmp);
	end
	if var then
		key="right";
		var2=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
		if var2 then
			var2=easy_chnnum2num(var2);
			rst=var.."."..var2;
			return 0,rst;
		end
	end
end

function M:pub_actpls_xmonth(attr)
	local var, curmonth, dstmonth;
	var=get_data_from_attr("offset",attr); --wtk_actpls_dict_get(d,"offset");
	curmonth=os.date("%m");
    curyear=os.date("%Y");
	dstmonth=curmonth+tonumber(var);
	if dstmonth>12 then
		dstmonth=dstmonth-12;
        curyear=curyear+1;
	elseif dstmonth<1 then
		dstmonth=dstmonth+12;
        curyear=curyear-1;
	end
	dstmonth=number_align(dstmonth);
	return 0,tostring(curyear)..tostring(dstmonth);
end

function M:pub_actpls_xday(attr)
	local key,var,curday,dstday;
        --local str = "M:pub_actpls_xday is called";
	--print(str);
	key="offset";
	var=get_data_from_attr(key,attr); --wtk_actpls_dict_get(d,key);
	curday=os.date("%d");
	if var then
--        dstday=curday+tonumber(var);
--		return 0,os.date("%Y%m")..tostring(dstday);
        dsttime=os.time() + tonumber(var)*24*3600;
        return 0,os.date("%Y%m%d",dsttime);
	end
	return 0,os.date("%Y%m%d");
end

function set_min_max(min,max,defaultvalue)
    local min1,max1;    
    if not min and not max then
        min1 = defaultvalue
        max1 = defaultvalue
    elseif min and not max then
        max1 = min
        min1 = min
    elseif not min and max then
        min1 = max
        max1 = max
    else
        min1 = min
        max1 = max
    end

    return min1,max1
end

--function M:pub_actpls_range_date(d,pls)
--	local key,var,year,var2,var3,month,day,from,to;
--	local minyear,maxyear,minmonth,maxmonth,minday,maxday,mintime,maxtime;
--	local yearflag, monthflag, dayflag;
--	key="type";
----	wtk_actpls_dict_print(d);
--	var=wtk_actpls_dict_get(d,key);
--	if var then
----		year=os.date("%Y");
--		var2=wtk_actpls_dict_get(d,"minyear");
--		var3=wtk_actpls_dict_get(d,"maxyear");
--		minyear,maxyear=determine_from_to_value(var2,var3,os.date("%Y"));
--		minyear=number_align(minyear);
--		maxyear=number_align(maxyear);
--		var2=wtk_actpls_dict_get(d,"minmonth");
--		var3=wtk_actpls_dict_get(d,"maxmonth");
--		minmonth,maxmonth=determine_from_to_value(var2,var3,os.date("%m"));
--		minmonth=number_align(minmonth);
--		maxmonth=number_align(maxmonth);
--		var2=wtk_actpls_dict_get(d,"minday");
--		var3=wtk_actpls_dict_get(d,"maxday");
--		minday,maxday=determine_from_to_value(var2,var3,os.date("%d"));
--		minday=number_align(minday);
--		maxday=number_align(maxday);
--		var2=wtk_actpls_dict_get(d,"mintime");
--		var3=wtk_actpls_dict_get(d,"maxtime");
--		mintime,maxtime=determine_from_to_value(var2,var3,os.date("%H:%M"));
--		if var=="month" then
--			from=tostring(minyear)..minmonth.."01";
--			if maxmonth=="02" then
--				if is_leap_year(maxyear) then
--					to=tostring(maxyear).."0229";
--				else
--					to=tostring(maxyear).."0228";
--				end
--			else
--				if MONTHDAYS[maxmonth] then
--					to=tostring(maxyear)..maxmonth..tostring(MONTHDAYS[maxmonth]);
--				else
--					to=os.date("%Y%m%d");
--				end
--			end
--			return 0,from.."<"..to;
--		elseif var=="day" then
--			from=minyear..minmonth..minday;
--			to=maxyear..maxmonth..maxday;
--			return 0,from.."<"..to;
--		elseif var=="time" then
--			from=mintime;
--			to=maxtime;
--			return 0, from.."<"..to;
--		elseif var=="year" then
--			from=minyear..minmonth..minday;
--			to=maxyear..maxmonth..maxday;
--			return 0, from.."<"..to;
--		end
--	end
--end


function M:pub_actpls_hour(attr)
	local key,var,hour,minute,tmp;
	key="hour";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
	  if var=='now' then 
      tmp=os.date("%H");
      --print(tmp)
    else
      tmp=wtk_chn2number(var);
    end		
		if tmp then
			hour=tmp;
		else
			hour=var;
		end
	else
		hour=0;
	end
	hour=number_align(hour);
	key="minute";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
	  if var=='now' then 
      tmp= os.date("%M");
      --print(tmp)
    else
      tmp=wtk_chn2number(var);
    end		
		if tmp then
			minute=tmp;
		else
			minute=var;
		end
	else
		minute=0;
	end
	minute=number_align(minute);

	return 0,tostring(hour)..":"..tostring(minute);
end

-- add by yan.fang
--处理的时间有三段如：三十秒：00:00:30
function M:pub_actpls_hour3(attr)
	local key,var,hour,minute,tmp;
	key="hour";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		tmp=wtk_chn2number(var);
		if tmp then
			hour=tmp;
		else
			hour=var;
		end
	else
		hour=0;
	end
	hour=number_align(hour);
	key="minute";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		tmp=wtk_chn2number(var);
		if tmp then
			minute=tmp;
		else
			minute=var;
		end
	else
		minute=0;
	end
	minute=number_align(minute);

    local second;
	key="second";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		tmp=wtk_chn2number(var);
		if tmp then
			second=tmp;
		else
			second=var;
		end
	else
        second=0
	end
	second=number_align(second);

	return 0,tostring(hour)..":"..tostring(minute)..":"..tostring(second);
end


function M:pub_actpls_hour3add12(attr)
	local key,var,hour,minute,tmp;
	key="hour";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	
	if var then
		--tmp=number_align(var)--
		wtk_chn2number(var);
		if tmp then
			hour=tmp+12;
		else
			hour=var+12;
		end
	else
		hour=0;
	end
	hour=number_align(hour);
	key="minute";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		tmp=wtk_chn2number(var);
		if tmp then
			minute=tmp;
		else
			minute=var;
		end
	else
		minute=0;
	end
	minute=number_align(minute);

    local second;
	key="second";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		tmp=wtk_chn2number(var);
		if tmp then
			second=tmp;
		else
			second=var;
		end
	else
        second=0
	end
	second=number_align(second);

	return 0,tostring(hour)..":"..tostring(minute)..":"..tostring(second);
end

function M:pub_actpls_timesub(d) --解决时间差说法，如:差三分钟五点
	local key,var,time,minute,tmp,hour,second;
	key="time";
	var=get_data_from_attr(key,d);--var=wtk_actpls_dict_get(d,key);
    splitlist = {}  
    
	if var then
        string.gsub(var, '[^:]+', function(w) table.insert(splitlist, w) end ) 
        if table.maxn(splitlist)~=3 then
            return var
        else
            hour=tonumber(splitlist[1])
            minute=tonumber(splitlist[2])
            second=tonumber(splitlist[3])
           -- print(hour,minute,second)
        end
	else
		hour=0;
        minute=0;
        second=0;
	end
	key="offset";
	offset=get_data_from_attr(key,d);--wtk_actpls_dict_get(d,key);
	if not offset then
        offset="00:00:00"
	end
    tpe=wtk_actpls_dict_get(d,"type");
    splitlist={}
    string.gsub(offset, '[^:]+', function(w) table.insert(splitlist, w) end )
    if table.maxn(splitlist)==3 then
        hour=hour-tonumber(splitlist[1])
        minute=minute-tonumber(splitlist[2])
        second=second-tonumber(splitlist[3])
    end       
    if second <0 then
        t1,t2 = math.modf(second/60)
        minute=minute+t1-1
        second=second-(t1-1)*60    
    end
    if minute<0 then
        t1,t2 = math.modf(minute/60)
        hour=hour+t1-1
        minute=minute-(t1-1)*60

       -- minute=minute+60
       -- hour=hour-1
    end
    if hour <0 then
        t1,t2 = math.modf(hour/24)
        hour=hour-(t1-1)*24
    end
	minute=number_align(minute);
	second=number_align(second);
	hour=number_align(hour);
	return 0,tostring(hour)..":"..tostring(minute)..":"..tostring(second);
end


function M:pub_actpls_xhour(attr)
	local key,var,offset,tmp;
    local hour,minute;
	key="hour";
    --print(key);
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
    offset=0;
	if var then
         tmp = wtk_chn2number(var);
        if tmp then
            hour=tmp;
        else
            hour=var;
        end
         offset = offset + tonumber(hour)*60;
    end
  	key="minute";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
    if var then
         tmp = wtk_chn2number(var);
        if tmp then
            minute=tmp;
        else
            minute=var;
        end

        offset = offset + tonumber(minute);
    end
       
	return 0,tostring(offset);
end




function M:pub_actpls_opt(attr)
	local key,var,var2,var3,var4,var5;
	key="opt";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
    local unit,rate;
    rate = 1.0;
	if var then
		var2=get_data_from_attr("value",attr); --wtk_actpls_dict_get(d,"value");
        unit=get_data_from_attr("unit",attr);--wtk_actpls_dict_get(d,"unit");
        if not unit then
            unit=""
        end
		if var2 then
			if var=="gt" then

--                var2=tonumber(var2)
--				var2=string.format("%0.2f",var2);
				return 0,var2..unit.."<";
			elseif var=="lt" then

--                var2=tonumber(var2)
--				var2=string.format("%0.2f",var2);
				return 0,"<"..var2..unit;
			elseif var=="gl" then
				var3=get_data_from_attr("prob",attr);--wtk_actpls_dict_get(d,"prob");
				var2=tonumber(var2);
				var3=tonumber(var3);
				var4=var2*(1-var3);
				var5=var2*(1+var3);
--				print(var4);
--				print(var5);
--				var4=string.format("%0.2f",var4);
--              var5=string.format("%0.2f",var5);
                var4=tostring(var4)
                var5=tostring(var5)
				return 0,var4.."<"..var5..unit;
            elseif var=="eq" then

--                tmp=tonumber(var2)
--                if tmp then
--                    var2=string.format("%0.2f",var2);
--                end
                return 0,var2..unit
			end
		end
	end
end

function M:pub_actpls_range(attr)
	local key,var,var2;
	key="min";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		key="max";
		var2=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
		if var2 then
            unit=get_data_from_attr("unit",attr);--wtk_actpls_dict_get(d,"unit");

--			var=string.format("%0.2f",var);
--			var2=string.format("%0.2f",var2);
            if unit then
                return 0, var.."<"..var2..unit;
            end
			return 0, var.."<"..var2;
		end
	end
end


function M:pub_actpls_sign(attr)
	local key,var,var2,sign;
	key="left";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
--    var = tonumber(var)
--    var=string.format("%0.2f",var);
	sign=get_data_from_attr("sign",attr);--wtk_actpls_dict_get(d,"sign");
    unit=get_data_from_attr("unit",attr);--wtk_actpls_dict_get(d,"unit");
    key="right";        
    var2=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		if var2 then
--			var2=tonumber(var2)
--			var2=string.format("%0.2f",var2);
            if unit then
                return 0, var..sign..var2..unit;
            end
			return 0, var..sign..var2;
		end
        if unit then
            return 0, var..sign..unit;
        end
     	return 0, var..sign;
    elseif var2 then
        if unit then
            return 0,sign..var2..unit
        end
        return 0,sign..var2
	end
end





function M:pub_actpls_price(attr)
	local key,var,num,min,max;
	key="weight";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if PRICEMAP[var] then
		num=PRICEMAP[var];
	end
	key="min";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		min=easy_chnnum2num(var);
	end
	key="max";
	var=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
	if var then
		max=easy_chnnum2num(var);
	end
	if min and max and num then
		min=string.format("%0.2f",tostring(tonumber(min)*num));
		max=string.format("%0.2f",tostring(tonumber(max)*num));
		return 0,min.."<"..max;
	end
end

function set_min_max(min,max,defaultvalue)
    local min1,max1;    
    if not min and not max then
        min1 = defaultvalue
        max1 = defaultvalue
    elseif min and not max then
        max1 = min
        min1 = min
    elseif not min and max then
        min1 = max
        max1 = max
    else
        min1 = min
        max1 = max
    end

    return min1,max1
end

-- by zhangyu, 2017-01-19
-- 新版本rangedate函数
function M:pub_actpls_rangedate(attr)
    local key,var,year,var1,var2,month,day,from,to;
    local minyear,maxyear;
    local minmonth,maxmonth;
    local minday,maxday,maxdayoffset,mindayoffset
    local tmp1,tmp2
    local datetype;
    key="type";
    datetype=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
    maxdayoffset=get_data_from_attr("maxdayoffset",attr);
    mindayoffset=get_data_from_attr("mindayoffset",attr);

    if datetype then        
        if datetype == "time" then
            var1 = get_data_from_attr("mintime",attr); --var1 = wtk_actpls_dict_get(d,"mintime");
            var2 = get_data_from_attr("maxtime",attr); --var2 = wtk_actpls_dict_get(d,"maxtime");            
            if var1 and var2 then
                return 0,var1.."<"..var2
            end
        end
        var1 = get_data_from_attr("minyear",attr)  --var1 = wtk_actpls_dict_get(d,"minyear");
        var2 = get_data_from_attr("maxyear",attr); --var2 = wtk_actpls_dict_get(d,"maxyear");
        minyear,maxyear = set_min_max(var1,var2,os.date("%Y"));
        if datetype == "year" then
            return 0,minyear.."<"..maxyear
        end
        var1 = get_data_from_attr("minmonth",attr); --var1 = wtk_actpls_dict_get(d,"minmonth");
        var2 = get_data_from_attr("maxmonth",attr); --var2 = wtk_actpls_dict_get(d,"maxmonth");
        minmonth,maxmonth = set_min_max(var1,var2,os.date("%m"));
        minmonth = number_align(minmonth);
        maxmonth = number_align(maxmonth);
        if datetype == "month" then
            return 0,minyear..minmonth.."<"..maxyear..maxmonth
        end

        var1 = get_data_from_attr("minwday",attr);--var1 = wtk_actpls_dict_get(d,"minwday");
        var2 = get_data_from_attr("maxwday",attr);--var2 = wtk_actpls_dict_get(d,"maxwday");
        if var1 and var2 then
            tmp1=wtk_chn2number(var1);
            tmp2=wtk_chn2number(var2);
            if tmp1 then 
                var1 = tmp1
            end
            if tmp2 then 
                var2 = tmp2
            end
            if tonumber(var2) < tonumber(var1) then
                tmp2 = tostring(var2)
                tmpy = tonumber(string.sub(tmp2,1,4))
                tmpm = tonumber(string.sub(tmp2,5,6))
                tmpd = tonumber(string.sub(tmp2,7,8))
                tmp2 = os.time({year=tmpy,month=tmpm,day=tmpd}) + 7*24*3600

                var2 = os.date("%Y%m%d",tmp2)
            end
        else
            var1 = get_data_from_attr("minday",attr);--wtk_actpls_dict_get(d,"minday");
            var2 = get_data_from_attr("maxday",attr);--wtk_actpls_dict_get(d,"maxday");
        end
        if var1 == "today" then
            var1=os.date("%d");
        elseif var1 == "yesterday" then
            var1 = os.time()-24 * 3600;
            var1 = os.date("%Y%m%d",var1);
        elseif var1 == "tomorrow" then
            var1 = os.time()+24 * 3600;
            var1 = os.date("%Y%m%d",var1);
        elseif var1== "w6" then
            off = 6 - os.date("%w");
            var1 = os.time() + off * 24 * 3600;
            var1 = os.date("%Y%m%d",var1)
        end
        if var2 == "today" then
            var2=os.date("%d");
        elseif var2 == "yesterday" then
            var2=os.time()-24 * 3600;
            var2 = os.date("%Y%m%d",var2);
        elseif var2 == "tomorrow" then
            var2=os.time()+24 * 3600;
            var2 = os.date("%Y%m%d",var2);
        elseif var2 == "w7" then
            off = 7 - os.date("%w");
            var2 = os.time() + off * 24 * 3600;
            var2 = os.date("%Y%m%d",var2)
        end
            
        tmp1=wtk_chn2number(var1);
        tmp2=wtk_chn2number(var2);
        if tmp1 then
            var1 = tmp1
        end
        if tmp2 then
            var2 = tmp2
        end
        if maxdayoffset then   --表示未来时，为了处理最近三天，新加的变量，最近N天表示：从今天开始算+后面的N-1天，故用maxdayoffset表示-1
            tmpoffset=tonumber(maxdayoffset);
            if tmpoffset then
                tmp2 = tostring(var2)
                tmpy = tonumber(string.sub(tmp2,1,4))
                tmpm = tonumber(string.sub(tmp2,5,6))
                tmpd = tonumber(string.sub(tmp2,7,8))
                tmp2 = os.time({year=tmpy,month=tmpm,day=tmpd})+tmpoffset*24*3600
                var2 = os.date("%Y%m%d",tmp2)
            end
        end
        if mindayoffset then   --表示过去时，为了处理最近三天，新加的变量，最近N天表示：从前面的N-1天到今天为止，故用mindayoffset表示1
            tmpoffset=tonumber(mindayoffset);
            if tmpoffset then
                tmp2 = tostring(var1)
                tmpy = tonumber(string.sub(tmp2,1,4))
                tmpm = tonumber(string.sub(tmp2,5,6))
                tmpd = tonumber(string.sub(tmp2,7,8))
                tmp2 = os.time({year=tmpy,month=tmpm,day=tmpd})+tmpoffset*24*3600
                var1 = os.date("%Y%m%d",tmp2)
                --var1=var1+tmpoffset
            end
        end
        minday,maxday = set_min_max(var1,var2,os.date("%d"));
        minday = number_align(minday);
        maxday = number_align(maxday);
        if datetype == "day" then
            if string.len(minday) == 2 then
                minday = minyear..minmonth..minday
            end
            if string.len(maxday) == 2 then
                maxday = maxyear..maxmonth..maxday
            end
            if minday==maxday then
                return 0,minday
            end
            return 0,minday.."<"..maxday  
        end           
    end
end

--[[    原始版本
function M:pub_actpls_rangedate(attr)
    local key,var,year,var1,var2,month,day,from,to;
    local minyear,maxyear;
    local minmonth,maxmonth;
    local minday,maxday
    local tmp1,tmp2
    local datetype;
    key="type";
    datetype=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
    if datetype then        
        if datetype == "time" then
            var1 = get_data_from_attr("mintime",attr); --var1 = wtk_actpls_dict_get(d,"mintime");
            var2 = get_data_from_attr("maxtime",attr); --var2 = wtk_actpls_dict_get(d,"maxtime");            
            if var1 and var2 then
                return 0,var1.."<"..var2
            end
        end
        var1 = get_data_from_attr("minyear",attr)  --var1 = wtk_actpls_dict_get(d,"minyear");
        var2 = get_data_from_attr("maxyear",attr); --var2 = wtk_actpls_dict_get(d,"maxyear");
        minyear,maxyear = set_min_max(var1,var2,os.date("%Y"));
        if datetype == "year" then
            return 0,minyear.."<"..maxyear
        end
        var1 = get_data_from_attr("minmonth",attr); --var1 = wtk_actpls_dict_get(d,"minmonth");
        var2 = get_data_from_attr("maxmonth",attr); --var2 = wtk_actpls_dict_get(d,"maxmonth");
        minmonth,maxmonth = set_min_max(var1,var2,os.date("%m"));
        minmonth = number_align(minmonth);
        maxmonth = number_align(maxmonth);
        if datetype == "month" then
            return 0,minyear..minmonth.."<"..maxyear..maxmonth
        end

        var1 = get_data_from_attr("minwday",attr);--var1 = wtk_actpls_dict_get(d,"minwday");
        var2 = get_data_from_attr("maxwday",attr);--var2 = wtk_actpls_dict_get(d,"maxwday");
        if var1 and var2 then
            tmp1=wtk_chn2number(var1);
            tmp2=wtk_chn2number(var2);
            if tmp1 then 
                var1 = tmp1
            end
            if tmp2 then 
                var2 = tmp2
            end
            if tonumber(var2) < tonumber(var1) then
                tmp2 = tostring(var2)
                tmpy = tonumber(string.sub(tmp2,1,4))
                tmpm = tonumber(string.sub(tmp2,5,6))
                tmpd = tonumber(string.sub(tmp2,7,8))
                tmp2 = os.time({year=tmpy,month=tmpm,day=tmpd}) + 7*24*3600

                var2 = os.date("%Y%m%d",tmp2)
            end
        else
            var1 = get_data_from_attr("minday",attr);--wtk_actpls_dict_get(d,"minday");
            var2 = get_data_from_attr("maxday",attr);--wtk_actpls_dict_get(d,"maxday");
        end
        if var1 == "today" then
            var1=os.date("%d");
        elseif var1 == "yesterday" then
            var1 = os.time()-24 * 3600;
            var1 = os.date("%Y%m%d",var1);
        elseif var1== "w6" then
            off = 6 - os.date("%w");
            var1 = os.time() + off * 24 * 3600;
            var1 = os.date("%Y%m%d",var1)
        end
        if var2 == "today" then
            var2=os.date("%d");
        elseif var2 == "yesterday" then
            var2=os.time()-24 * 3600;
            var2 = os.date("%Y%m%d",var2);
        elseif var2 == "w7" then
            off = 7 - os.date("%w");
            var2 = os.time() + off * 24 * 3600;
            var2 = os.date("%Y%m%d",var2)
        end
            
        tmp1=wtk_chn2number(var1);
        tmp2=wtk_chn2number(var2);
        if tmp1 then
            var1 = tmp1
        end
        if tmp2 then
            var2 = tmp2
        end
        minday,maxday = set_min_max(var1,var2,os.date("%d"));
        minday = number_align(minday);
        maxday = number_align(maxday);
        if datetype == "day" then
            if string.len(minday) == 2 then
                minday = minyear..minmonth..minday
            end
            if string.len(maxday) == 2 then
                maxday = maxyear..maxmonth..maxday
            end
            if minday==maxday then
                return 0,minday
            end
            return 0,minday.."<"..maxday  
        end           
    end
end
]]


function M:pub_actpls_opt_date(attr)
	local key,optval,val,offset,val1,val2;
    local datetype,curyear,curmonth;
	key="opt";
	optval=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);

	if optval then
		val=get_data_from_attr("value",attr);--wtk_actpls_dict_get(d,"value");
        datetype=get_data_from_attr("type",attr);--wtk_actpls_dict_get(d,"type");

        offset=get_data_from_attr("offset",attr);--wtk_actpls_dict_get(d,"offset");
        if offset then
            offset=tonumber(offset);
            if datetype == "year" then
                curyear=tonumber(os.date("%Y"));
                val1=curyear - offset;
                val2=curyear + offset;
            elseif datetype == "month" then
                curyear=tonumber(os.date("%Y"));
                curmonth=tonumber(os.date("%m"));
                val1=curmonth - offset;
                val2=curmonth + offset;
                if val1 < 1 then
                    val1 = val1 + 12;
                    curyear = curyear - 1;
                elseif val1 > 12 then
                    val1 = val1 - 12;
                    curyear = curyear + 1;
                end
                if val2 < 1 then
                    val2 = val2 + 12;
                    curyear = curyear - 1;
                elseif val2 > 12 then
                    val2 = val2 - 12;
                    curyear = curyear + 1;
                end
                val1 = number_align(val1);
                val2 = number_align(val2);
                val1 = tostring(curyear)..tostring(val1);
                val2 = tostring(curyear)..tostring(val2);
            elseif datetype == "day" then
                val = os.time();
                val1=val - offset * 24 * 3600;
                val2=val + offset * 24 * 3600;
                val1=os.date("%Y%m%d",val1);
                val2=os.date("%Y%m%d",val2);
            end
        elseif val then
            val1=val;
            val2=val;
        end
        val1=tostring(val1);
        val2=tostring(val2);
		if optval=="gt" then
			return 0,val2.."<";
		elseif optval=="lt" then
			return 0,"<"..val2;
		elseif optval=="gl" then
			return 0,val1.."<"..val2;
        elseif optval=="eq" then
            return 0,val2;
		end

	end
end


function M:pub_actpls_week(attr)
    local key,offset;
    local wday;
    local dstday1,dstday2;
    wday = os.date("%w");
    if wday=='0' then --周日默认成一周的第七天
        wday=7
    end
    wday=tonumber(wday);
    key="offset";
    offset=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
    offset = tonumber(offset);
    if offset < 0  then
        dstday1 = os.time() - (wday+1)*24*3600 + (offset+1)*7*24*3600;
        dstday1 = os.date("%Y%m%d",dstday1);
        dstday2 = os.time() - (wday+1)*24*3600 + (offset+1)*7*24*3600 - 6*24*3600;
        dstday2 = os.date("%Y%m%d",dstday2);
        return 0,tostring(dstday2).."<"..tostring(dstday1);
    elseif offset > 0 then
        dstday1 = os.time() + (7-wday)*24*3600 + (offset-1)*7*24*3600;
        dstday1 = os.date("%Y%m%d",dstday1);
        dstday2 = os.time() + (7-wday)*24*3600 + (offset-1)*7*24*3600 + 6*24*3600;
        dstday2 = os.date("%Y%m%d",dstday2);
        return 0,tostring(dstday1).."<"..tostring(dstday2);
    elseif offset == 0 then
        dstday1 = os.time() - wday*24*3600
        dstday1 = os.date("%Y%m%d",dstday1);
        dstday2 = os.time() + (7-wday-1)*24*3600
        dstday2 = os.date("%Y%m%d",dstday2)
        return 0,tostring(dstday1).."<"..tostring(dstday2);
    end
end


local ordict={};
local anddict={};

function pub_reset_anddict()
	anddict={};
end

function anddict_add_item(s)
	local al,i,flag;
	
	al=table.maxn(anddict);
	for i=1, al do
		if anddict[i]==s then
			flag=true;
			break;
		end
	end
	if not flag then
		table.insert(anddict,s);
	end
end

function pub_reset_ordict()
	ordict={};
end

function ordict_add_item(s)
	local al,i,flag;
	
	al=table.maxn(ordict);
	for i=1, al do
		if ordict[i]==s then
			flag=true;
			break;
		end
	end
	if not flag then
		table.insert(ordict,s);
	end
end

--function M:pub_actpls_or(d,pls)
--	local var, i, al, rst, var2;
--	pub_reset_ordict();
--	wtk_actpls_dict_print(d);
--	var=wtk_actpls_dict_get2(d,"item1");
--	if var then
--	    for i=1, table.maxn(var) do
--			var2=var[i];
--			ordict_add_item(var2);
--		end
--	end
--	var=wtk_actpls_dict_get2(d,"item2");
--	if var then
--	    for i=1, table.maxn(var) do
--			var2=var[i];
--			ordict_add_item(var2);
--		end
--	end
--	al=table.maxn(ordict);
--	if al>0 then
--		rst='';
--		for i=1, al do
--			rst=rst..ordict[i].."|";
--		end
--		rst=string.sub(rst,1,string.len(rst)-1); 
--	end
--	if rst then
--		return 0,rst;
--	else
--		return 0,"or error.";
--	end
--end

--function M:pub_actpls_and(d,pls)
--	local var, i, al, rst, var2;
--	pub_reset_anddict();
--	wtk_actpls_dict_print(d);
--	var=wtk_actpls_dict_get2(d,"item1");
--	if var then
--	    for i=1, table.maxn(var) do
--			var2=var[i];
--			anddict_add_item(var2);
--		end
--	end
--	var=wtk_actpls_dict_get2(d,"item2");
--	if var then
--	    for i=1, table.maxn(var) do
--			var2=var[i];
--			anddict_add_item(var2);
--		end
--	end
--	al=table.maxn(anddict);
--	if al>0 then
--		print_obj(anddict);
--		rst='';
--		for i=1, al do
--			rst=rst..anddict[i].."&";
--		end
--		rst=string.sub(rst,1,string.len(rst)-1); 
--	end
--	if rst then
--		print(rst);
--		return 0,rst;
--	else
--		return 0,"or error.";
--	end
--end

local mixDict={};

function get_mix_dict()
	--print("in actpls");
	--print(mixDict);
	--print_obj(mixDict);
	return mixDict;
end

function reset_mix_dict()
	mixDict={};
end

function add_mix_dict(s)
	local var, i, al,flag;
	al=table.maxn(mixDict);
	for i=1,al do
		var=mixDict[i];
		if var==s then
			flag=true;
			break;
		end
	end
	if not flag then
		table.insert(mixDict,s);
	end
end

function dict_has_item(s)
	local i,al,var,s2,rst;
	al=table.maxn(mixDict);
	rst=false;
	for i=1, al do
		var=mixDict[i];
		s2=string.sub(var,2,string.len(var));
		if s2==s then
			rst=true;
			break;
		end
	end
	return rst,var;
end

function update_item_table(tbl)
	local i,al,var,flag,value;
	
	al=table.maxn(tbl);
	for i=1, al do
		var=tbl[i];
		flag,value=dict_has_item(var);
		if flag then
			tbl[i]=value;
		end
	end
	return tbl;
end

function M:pub_actpls_or(attr)
    local key,itemtable,item;
    item="";
--    wtk_actpls_dict_print(d);
    itemtable=get_data_from_attr("item",attr);--wtk_actpls_dict_get2(d,"item");
    if type(itemtable)=="string" then
        item= "|"..itemtable;        
        add_mix_dict("|"..itemtable);
    else
        itemtable=update_item_table(itemtable);
        for i=1, table.maxn(itemtable) do
            if string.sub(itemtable[i],1,1) == "&" or string.sub(itemtable[i],1,1) == "!" or string.sub(itemtable[i],1,1) == "|" then
                item=item..itemtable[i];
            else  
                item=item.."|"..itemtable[i];
                add_mix_dict("|"..itemtable[i]);
            end
        end
    end
    if item then
        return 0,item
    end
end


function M:pub_actpls_and(attr)
    local key,itemtable,item;
    item="";
--    wtk_actpls_dict_print(d);
    itemtable=get_data_from_attr("item",attr);--wtk_actpls_dict_get2(d,"item");
    if type(itemtable)=="string" then        
        item= "&"..itemtable;
        add_mix_dict("&"..itemtable)
    else
        itemtable=update_item_table(itemtable);
        for i=1, table.maxn(itemtable) do
            if string.sub(itemtable[i],1,1) == "&" or string.sub(itemtable[i],1,1) == "!"  or string.sub(itemtable[i],1,1) == "|" then
                item=item..itemtable[i];
            else  
                item=item.."&"..itemtable[i];
                add_mix_dict("&"..itemtable[i]);
            end
        end
    end
    if item then
        return 0,item
    end
end


function M:pub_actpls_not(attr)
    local key,itemtable,item;
    item="";
--    wtk_actpls_dict_print(d);
    itemtable=get_data_from_attr("item",attr);--wtk_actpls_dict_get2(d,"item");
    if type(itemtable)=="string" then
        item = "!"..itemtable
        add_mix_dict("!"..itemtable);
    else
        itemtable=update_item_table(itemtable);
        for i=1, table.maxn(itemtable) do
            if string.sub(itemtable[i],1,1) == "&" or string.sub(itemtable[i],1,1) == "!"  or string.sub(itemtable[i],1,1) == "|" then
                item=item..itemtable[i];
            else  
                item=item.."!"..itemtable[i];
                add_mix_dict("!"..itemtable[i]);
            end
        end
    end
    if item then
        return 0,item
    end
end

function M:pub_actpls_compare(d)
    local key,itemtable,item;
    item="";
--    wtk_actpls_dict_print(d);
    itemtable=get_data_from_attr("item",d)--wtk_actpls_dict_get2(d,"item");
    if type(itemtable)=="string" then
        item = "^"..itemtable
        add_mix_dict("^"..itemtable);
    else
        itemtable=update_item_table(itemtable);
        for i=1, table.maxn(itemtable) do
            if string.sub(itemtable[i],1,1) == "&" or string.sub(itemtable[i],1,1) == "^" then
                item=item..itemtable[i];
            else  
                item=item.."^"..itemtable[i];
                add_mix_dict("^"..itemtable[i]);
            end
        end
    end
    if item then
        return 0,item
    end
end

function M:pub_actpls_count(attr)
    local key,valuetab,counttab,count,value;
    local i,j,val;
    --wtk_actpls_dict_print(d);
    key = "count";
    counttab=get_data_from_attr(key,attr);--wtk_actpls_dict_get2(d,key);    
    --print_obj(counttab);
    key = "value";
    valuetab = get_data_from_attr(key,attr);--wtk_actpls_dict_get2(d,key);
    --print(counttab,valuetab)
    count = tonumber(counttab)
    value = valuetab
    for i=1,count do
        if i == 1 then
            val = value
        else
            val = val..value
        end
    end
    --[[
    val = value;
    for j=1,table.maxn(counttab) do
        count = counttab[j];
        value = valuetab[j];
        for i=1,count do
            if j==1 and i ==1 then
                val = value;
            else
                val=val..value;
            end
        end
    end
    --]]
    --print(val)
    return 0,val;
end


function M:pub_actpls_join(attr)
    local key,prefix,mid,suffix;
    key="prefix";
    prefix=get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
    --print(prefix);

    key="mid";
    mid = get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);
    --print(mid);

    key="suffix";
    suffix = get_data_from_attr(key,attr);--wtk_actpls_dict_get(d,key);

    if not suffix then
        return 0,prefix..mid
    end

    return 0,prefix..mid..suffix
    
end


function M:pub_actpls_join2(attr)
    local key,prefix,mid;
    local i,j,val;
    key="prefix";
    prefix=get_data_from_attr(key,attr);--wtk_actpls_dict_get2(d,key);
    --print_obj(prefix);

    key="mid";
    mid = get_data_from_attr(key,attr);--wtk_actpls_dict_get2(d,key);
    --print_obj(mid);
    --print(mid)
    --[[ charles: 临时解决方案
    val = "";
    for i=1,table.maxn(prefix) do
        if mid and mid[i] then
            val=val..prefix[i]..mid[i];
        else 
            val=val..prefix[i];
        end
    end
    --]]
    val = ""
    if prefix then
        val = prefix
    end
    if mid then
        val = val..mid
    end
    
    return 0,val;
end

function M:pub_actpls_logical(attr)
    local key,item1,item2;
--    wtk_actpls_dict_print(d);    
    item1=get_data_from_attr("item1",attr);--wtk_actpls_dict_get(d,"item1");
    item2=get_data_from_attr("item2",attr);--wtk_actpls_dict_get(d,"item2");    
    return 0,item1..item2
end

function actpls_reset(attr)
	mixDict={};
	return 0,"";
end

function process_table_in_attr(s)
	local key,key2,ret;	
	for i,v in pairs(s) do       --先遍历,处理所有的table,table里有post则返回值,无则返回空
		if( str == "table" ) then
           	ret = process_table_in_attr(v);
            if(ret ~= nil) then
                 s[i] = ret;
            end
        end
    end
	key  = "__POST__";
--	key2 = "attr";
	if( s[key]~=nil ) then
		ret = post_request_process(s[key], s );
	else
		ret = nil;
	end
	return ret;
end

function get_data_from_attr(k,attr)
    local key,var,ret,str;	
--[[
    for i,v in pairs(attr) do   
		if( type(attr[i]) == "table" ) then
			ret = process_table_in_attr(attr[i]);
            if(ret ~= nil) then
                attr[i] = ret;
            end
        end
    end
--]]
    if type(attr) == "table" then
        ret=attr[k];
    else
        if type(attr) == "string" then
            ret = attr
        end
    end	        
    return ret;
end

--' '   (0x20)	space (SPC) 空格符
--'\t'	(0x09)	horizontal tab (TAB) 水平制表符	
--'\n'	(0x0a)	newline (LF) 换行符
--'\v'	(0x0b)	vertical tab (VT) 垂直制表符
--'\f'	(0x0c)	feed (FF) 换页符
--'\r'	(0x0d)	carriage return (CR) 回车符

function isspace(c)
    local ret = false;
--    print("isspace:",c);
    if( c==0x20 or c==0x09 or c==0x0a or c == 0x0b or c== 0x0c or c==0x0d ) then
--        print("yes,it's space")
        ret=true;
    end
    return ret;
end

--若参数c 为英文字母（a0x61 ~ z0x7a  A0x41 ~ Z0x5a），则返回true 值，否则返回 false。
function isalpha(c)
    local ret = false;
    if( (c >= 0x61 and c<= 0x7a) or ( c>=0x41 and c<= 0x5a) ) then
        ret = true;
    end
    return ret;
end
                    
function wtk_chnstr_atoi3(d)
  local map = {};
        --local str = "%d,%d,%d"
        --print(string.byte(d,1),string.byte(d,2),string.byte(d,3));
  map["\233\155\182"] = 0; --      {wtk_string("\xe9\x9b\xb6"), 0},         // ling2
  map["\228\184\128"] = 1; --      {wtk_string("\xe4\xb8\x80"), 1},         // yi1
  map["\229\185\186"] = 1; --      {wtk_string("\xe5\xb9\xba"), 1},         // yao1
  map["\228\184\164"] = 2; --      {wtk_string("\xe4\xb8\xa4"), 2},         // liang2
  map["\228\186\140"] = 2; --      {wtk_string("\xe4\xba\x8c"), 2},         // er4
  map["\228\184\137"] = 3; --      {wtk_string("\xe4\xb8\x89"), 3},         // san1
  map["\229\155\155"] = 4; --      {wtk_string("\xe5\x9b\x9b"), 4},         // si4
  map["\228\186\148"] = 5; --      {wtk_string("\xe4\xba\x94"), 5},         // wu3
  map["\229\133\173"] = 6; --      {wtk_string("\xe5\x85\xad"), 6},         // liu4
  map["\228\184\131"] = 7; --      {wtk_string("\xe4\xb8\x83"), 7},         // qi1
  map["\229\133\171"] = 8; --      {wtk_string("\xe5\x85\xab"), 8},         // ba1
  map["\228\185\157"] = 9; --      {wtk_string("\xe4\xb9\x9d"), 9},         // jiu3
  map["\229\141\129"] = 10;--      {wtk_string("\xe5\x8d\x81"), 10},        // shi2
  map["\231\153\190"] =100;--      {wtk_string("\xe7\x99\xbe"), 100},       // bai3
  map["\229\141\131"] =1000;--     {wtk_string("\xe5\x8d\x83"), 1000},      // qian1
  map["\228\184\135"] =10000;--    {wtk_string("\xe4\xb8\x87"), 10000},     // wan4
  map["\228\186\191"] =100000000-- {wtk_string("\xe4\xba\xbf"), 100000000}, // yi4
    return map[d];
end

function wtk_chn2number(s)
    local len = string.len(s);
    local spos, epos;
    local n = 0;
    local num=3;
    local yi = 0;
    local inc = -1;
    local t, last_t;
    local last_unit = 0;
    local str;

    spos = 1;
    epos = len - num + 1;
    last_t = -1;
    last_not_zero = -1
    if len < num then
        return nil
    end    
    while (spos <= epos ) 
    do
        --  num = wtk_utf8_bytes(*s);
       
        str = string.sub(s,spos,spos+num-1);        
        t = wtk_chnstr_atoi3(str);
    
        if (t == nil) then
            n = nil;
            return n;
        end
                
        if t < 10 then
            if inc > 0 then
                inc = inc*10+t;
                        last_unit =0                        
            else
                if (n > 0 and t >= 0) then
                    last_unit = 1;                            
                end
                if( t == 0) then
                    last_t=0
                end
                inc = t;
              end
        else 
            if (inc == -1) then
                if (n == 0) then
                    n = t;
                else
                    if (t<last_t) then
                        n = n+t
                    else 
                        n = n*t;
                    end
                end
            else 
                if (t < last_t) then
                    inc = inc*t;
                    n = n+inc;
                else 
                    if t < last_not_zero then
                        if inc == 0 then
                            n = n + t;                    
                        else
                            n = n + t * inc
                        end
                    else
                        n = n+inc;
                        n = n*t;
                    end
                end
            end

            if (t >= 100000000) then
                yi = n;
                n = 0;
            elseif t>=10000 then
                yi = yi+n;
                n=0
            end
            inc = -1;
            last_t = t;
            last_not_zero = t
        end
        spos = spos+num;
        if (spos > epos and inc > 0) then
            if ( last_unit~=0 and last_t > 0) then
                inc = inc * last_t / 10;                
            end
            n = n + inc;
        end
    end    
    return yi + n;
end

return M
