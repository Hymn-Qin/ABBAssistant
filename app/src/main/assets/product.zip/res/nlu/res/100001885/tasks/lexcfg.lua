local name = "nlucore";
local lexdb = {};

lexdb.use_trie = 1;
lexdb.data = {};
lexdb.pwd = "${pwd}";
lexdb.ext_path = lexdb.pwd .. "/../vocabs";

lexdb.data["sys.绝对音量"] = "/data/resources/semantic/builtin_vocabs//sys.绝对音量.bin";
lexdb.data["sys.技能操作词"] = lexdb.pwd .. "/../vocabs/sys.技能操作词.bin";
lexdb.data["sys.房间名称"] = "/data/resources/semantic/builtin_vocabs//sys.房间名称.bin";
lexdb.data["sys.相对音量"] = "/data/resources/semantic/builtin_vocabs//sys.相对音量.bin";
lexdb.data["sys.技能调用名"] = lexdb.pwd .. "/../vocabs/sys.技能调用名.bin";
return lexdb;
